<?php require 'esqueleto.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="./css/styleevent.css" rel="stylesheet">
    <title>Eventos</title>
</head>
<body>
    
    <div class="content">
        <aside>
        <h1    style ='margin: 1px;'>Eventos Escolares</h1>
        <h2>Eventos realizados pela escola para atribuição de pontos e para interação entre alunos.</h2>
        </aside>
        <br><br>
        <div class='tableEventos'>
        <table>
            <td><img src="./svg's/promover-eventos-na-escola.jpg" width="150px" height="150px"><br><h3>Evento1</h3><br><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor neque vitae tempus quam pellentesque. A condimentum vitae sapien pellentesque habitant morbi tristique senectus et. Sollicitudin nibh sit amet commodo nulla facilisi nullam vehicula ipsum. Et ligula ullamcorper malesuada proin libero nunc consequat interdum varius. Elementum facilisis leo vel fringilla est ullamcorper eget nulla. Augue eget arcu dictum varius. Fames ac turpis egestas sed tempus urna et pharetra pharetra. Facilisi morbi tempus iaculis urna id volutpat lacus. Volutpat blandit aliquam etiam erat velit scelerisque.</p></td>
        </table>
        </div>
    </div>
</body>
</html>